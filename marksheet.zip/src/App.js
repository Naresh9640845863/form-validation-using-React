import logo from './logo.svg';
import './App.css';
import TenthForm from './components/TenthForm';

function App() {
  return (
    <div className="App">
      <TenthForm/>
    </div>
  );
}

export default App;
